package Exercicios;

import java.util.Scanner;

public class Exercicio10 {

	public static void main(String[] args) {
		// 10. Desenvolva um programa que calcule o Índice de Massa Corporal (IMC) a
		// partir do peso e altura
		// informados pelo usuário, e informe a categoria de acordo com a tabela IMC.

		Scanner leia = new Scanner(System.in);

		System.out.println("Informe seu peso");
		double peso = leia.nextDouble();

		System.out.println("Informe sua altura");
		double altura = leia.nextDouble();
		leia.close();
		double imc;
		imc = peso / (altura * altura);
		System.out.println("IMC é " + imc);
		if (imc <= 17) {
			System.out.println("Muito abaixo do peso");
		} else if (imc < 18.49) {
			System.out.println("abaixo do peso");
		} else if (imc < 24.99) {
			System.out.println("peso normal");
		} else if (imc < 29.99) {
			System.out.println("Acima do peso");
		} else if (imc < 34.99) {
			System.out.println("Obesidade 1");
		} else if (imc < 39.99) {
			System.out.println("Obesidade 2");
		} else {
			System.out.println("Obesidade 3");
		}

	}

}

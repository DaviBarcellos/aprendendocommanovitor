package Exercicios;

import java.util.Scanner;

public class Exercicio02 {
    //2. Fazer um programa para ler um número inteiro e dizer se este número é par ou ímpar.
	public static void main(String[] args) {
		
		Scanner leia= new Scanner(System.in);
		
		System.out.println("Digite um numero");
		
		int num = leia.nextInt();
		
		if (num%2 == 0) {
		
			System.out.println("Par");}
	    else { 
			System.out.println("Impar");
			
		}
		
		leia.close();
		
		
		

	}

}
